# @maxwellclinic/commit-rag-mcp

Local commit-aware RAG package powered by sqlite-vec with MCP tool endpoints.

## Features

- Indexes git commits across branches into commit-file chunks
- Embeds chunks using a local embedding source (Ollama when configured)
- Stores vectors in sqlite-vec (SQLite)
- Exposes MCP tools for agent workflows

## MCP tools

- `search_related_commits`
- `explain_commit_match`
- `get_commit_diff`

## Quick start

```bash
npm install @maxwellclinic/commit-rag-mcp
npx commit-rag-index --repo /path/to/repo --db /path/to/repo/.commit-rag.db --limit 400
npx commit-rag-mcp
```

## Publish

```bash
npm run build
npm publish --access public
```

## VS Code MCP registration

Copy `mcp.config.example.json` entries into your user MCP config and adjust paths/env values.

## Environment

- `COMMIT_RAG_REPO` default repository path for MCP
- `COMMIT_RAG_DB` sqlite db path
- `COMMIT_RAG_LIMIT` max commits to index per run
- `OLLAMA_BASE_URL` local ollama URL (default `http://127.0.0.1:11434`)
- `OLLAMA_EMBED_MODEL` local embedding model name

If `OLLAMA_EMBED_MODEL` is not set, the package uses deterministic local fallback embeddings.
